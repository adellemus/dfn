$(document).ready(function(){
var software=0;
var hardware=0;
var funcionamiento=0;
var otros=0;
$("#servicio").focus();
$(".gift2").hide();
$("#divotros").hide();





 $(document).on('click', '#eliminar_informe', function() {

		var id_servicio_especial=this.dataset.id_servicio_especial;
 
	 alertify.confirm( "¿Esta realmente seguro de eliminar este informe?", function (e) {
			    if (e) {
			    	 $.post(base_url + 'informes/eliminar_informe',{
			id_servicio_especial:id_servicio_especial
			},function(){
				alertify.alert("Informe eliminado exitosamente");
				setTimeout('document.location.reload()',1000);
	           });
			        
			    } else {
			       alertify.error('Ha cancelado la operación');
			    }
			}); 

    });

});