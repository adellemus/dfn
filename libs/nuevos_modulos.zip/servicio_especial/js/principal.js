$(document).ready(function(){
$("#diagnostico").hide();
//$("#adjuntar_fotos").hide();
$("#form_partes").hide();


$(document).on("change","#requiere_partes",function(){
 if($("#requiere_partes:checked").val()=="Si") {  
        
        $("#form_partes").show(1000);
        }else{

        $("#form_partes").hide(1000);
        }

});

$(document).on("change","#fotos_informe",function(){
 if($("#fotos_informe:checked").val()=="Si") {  
        
        $("#adjuntar_fotos").show(1000);
        }else{

        	$("#adjuntar_fotos").hide(1000);
        }

});

$(document).on('click', '#registrar_equipo', function() {

			if($("#id_cliente").val()==''){

				alertify.alert('Por favor seleccione un Cliente');
			}else{
	 		
	 		if($("#equipo").val() =='' || $("#modelo").val()=='' || $("#serie").val()=='' || $("#daño").val()=='' || $("#contador").val()==''){

	 			alertify.alert('Por favor llene todos los campos');

	 		}else{
			    	$.post(base_url+'servicio_especial/registrar_equipo',{

			    		equipo:$("#equipo").val(),
			    		modelo:$("#modelo").val(),
			    		serie:$("#serie").val(),
			    		daño:$("#daño").val(),
			    		contador:$("#contador").val(),
			    		id_cliente:$("#id_cliente").val()

						},function(datos) {
						console.log(datos);
						$("#id_servicio_especial").val(datos);
						//$("cliente").val("");
						$("#equipo").prop('disabled', true);
						$("#contador").prop('disabled', true);
						$("#modelo").prop('disabled', true);
						$("#serie").prop('disabled', true);
						$("#daño").prop('disabled', true);
						$("#diagnostico").show(1500);
						alertify.success('Equipo registrado en el servicio exitosamente.');
					},"json");
		}}
	});

$(document).on('click', '#registrar_estado', function() {

	if($("#estado_inicial").val()==''){

				alertify.alert('Por favor llene el campo correctamente');
			}else{
	 		
	 		
			    	$.post(base_url+'servicio_especial/registrar_estado',{

			    		estado_inicial:$("#estado_inicial").val(),
			    		id_servicio_especial:$("#id_servicio_especial").val()

						},function() {
						//$("cliente").val("");
						$("#estado_inicial").val("");
						alertify.success('Estado inicial registrado en el servicio exitosamente.');
					});
		}
	});

$(document).on('click', '#registrar_pruebas', function() {
	 		
	 			if($("#pruebas_ejecutadas").val()==''){

				alertify.alert('Por favor llene el campo correctamente');
			}else{
	 		
	 		
			    	$.post(base_url+'servicio_especial/registrar_pruebas',{

			    		pruebas_ejecutadas:$("#pruebas_ejecutadas").val(),
			    		id_servicio_especial:$("#id_servicio_especial").val()

						},function() {
						//$("cliente").val("");
						$("#pruebas_ejecutadas").val("");
						alertify.success('Prueba registrada en el servicio exitosamente.');
					});
		}
	});

$(document).on('click', '#registrar_observaciones', function() {
	 		
	 		if($("#observaciones").val()==''){

				alertify.alert('Por favor llene el campo correctamente');
			}else{
			    	$.post(base_url+'servicio_especial/registrar_observaciones',{

			    		observaciones:$("#observaciones").val(),
			    		id_servicio_especial:$("#id_servicio_especial").val()

						},function() {
						//$("cliente").val("");
						$("#observaciones").val("");
						alertify.success('Observacion registrada en el servicio exitosamente.');
					});
		}
	});


$(document).on('click', '#registrar_parte', function() {
	 		
	 		if($("#descripcion_parte").val()=='' || $("#parte").val()==''){

				alertify.alert('Por favor llene los campos correctamente');
			}else{
			    	$.post(base_url+'servicio_especial/registrar_parte',{

			    		parte:$("#parte").val(),
			    		descripcion_parte:$("#descripcion_parte").val(),
			    		id_servicio_especial:$("#id_servicio_especial").val()

						},function() {
						//$("cliente").val("");
						$("#parte").val("");
						$("#descripcion_parte").val("");
						alertify.success('Parte registrada en el servicio exitosamente.');
					});
		}
	});


});