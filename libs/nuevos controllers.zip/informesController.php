<?php


class informesController extends Controller
{
	
	private $_index;
    public function __construct() {
        parent::__construct();
        $this->getLibrary('simpleimage');
  	 $this->_index=$this->loadModel('informes');	
      
    }

    public function index()
    {


			if(!Session::get('autenticado')){
            $this->redireccionar('login');
        }
        
			$this->_view->setJs(array('principal'));
			$this->_view->setCss(array('css','style'));
        	$this->_view->titulo = 'Informes - COTEDEM';

        	$informes=$this->_index->buscar_informes();
        	
        	$this->_view->informes=$informes;
			$this->_view->renderizar('index');

							
			
	}


function eliminar_informe(){
    $this->_index->eliminar_informe($_POST['id_servicio_especial']);
    }


    function buscar_servicio_usuario(){

       echo json_encode( $this->_index->buscar_servicio_usuario($_POST['servicio'],$_POST['estatus']));
    }


	
	
}


?>