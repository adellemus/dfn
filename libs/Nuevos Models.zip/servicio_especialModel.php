<?php

class servicio_especialModel extends Model
{
    public function __construct() {
        parent::__construct();
    }



    public function registrar_equipo($datos){

 $sql="INSERT INTO servicio_especial values ('','".$datos['equipo']."','".$datos['modelo']."' ,'".$datos['serie']."' ,'".$datos['daño']."',curdate(),'".$datos['id_cliente']."')";
        $this->_db->query($sql);

        $id_servicio_especial=$this->_db->lastInsertId();

        $sql2="INSERT INTO diagnostico values ('','".$datos['contador']."','".$id_servicio_especial."')";
        $this->_db->query($sql2);

        return $id_servicio_especial;
   }


   public function registrar_estado($datos){

 $sql="INSERT INTO estado_inicial values ('','".$datos['estado_inicial']."','".$datos['id_servicio_especial']."')";
        $this->_db->query($sql);

   }

public function registrar_fotos($datos,$fotos){

   if($fotos['foto']['name'][0]==''){


   }else{

 if(count($fotos['foto']['name']) < 3){

$recorrido=count($fotos['foto']['name']);

}else{
$recorrido=3;
}

 for ($i=0; $i < $recorrido; $i++){ 

                  $cadena = str_replace(' ', '', $fotos['foto']['name'][$i]);
                  $target_path = "public/img/informes/";
                  $nombre=uniqid('informe').$cadena;
                  $target_path = $target_path .$nombre;
                   $sql2="insert into foto_servicio_especial values('','".$nombre."','".$datos['id_servicio_especial']."','')";
                  $this->_db->query($sql2);
                  move_uploaded_file($fotos['foto']['tmp_name'][$i], $target_path);
                  $obj_img = new SimpleImage();
                  $obj_img->load($target_path);
                  $obj_img->resize(400,300);
                  $obj_img->save($target_path);
            }
}
   }



   public function registrar_pruebas($datos){

 $sql="INSERT INTO pruebas_ejecutadas values ('','".$datos['pruebas_ejecutadas']."','".$datos['id_servicio_especial']."')";
        $this->_db->query($sql);

   }

   public function registrar_observaciones($datos){

 $sql="INSERT INTO observaciones values ('','".$datos['observaciones']."','".$datos['id_servicio_especial']."')";
        $this->_db->query($sql);

   }

   public function registrar_parte($datos){

 $sql="INSERT INTO partes values ('','".$datos['parte']."','".$datos['descripcion_parte']."','".$datos['id_servicio_especial']."')";
        $this->_db->query($sql);

   }


public function buscar_servicio_especial($id){

   $sql="SELECT * FROM servicio_especial,clientes WHERE clientes.id_clientes=servicio_especial.id_cliente and servicio_especial.id_servicio_especial='".$id."'";
  
   $datos = $this->_db->query($sql);
    $datos->setFetchMode(PDO::FETCH_ASSOC);
    $this->datoss = $datos->fetch();
   }

public function buscar_estado_inicial($id){

   $sql="SELECT * FROM estado_inicial where id_servicio_especial='".$id."'";
  
   $datos = $this->_db->query($sql);
    $datos->setFetchMode(PDO::FETCH_ASSOC);
    $this->datoss = $datos->fetchall();
   }
public function buscar_pruebas_ejecutadas($id){

   $sql="SELECT * FROM pruebas_ejecutadas where id_servicio_especial='".$id."'";
  
   $datos = $this->_db->query($sql);
    $datos->setFetchMode(PDO::FETCH_ASSOC);
    $this->datoss = $datos->fetchall();
   }

   public function buscar_observaciones($id){

   $sql="SELECT * FROM observaciones where id_servicio_especial='".$id."'";
  
   $datos = $this->_db->query($sql);
    $datos->setFetchMode(PDO::FETCH_ASSOC);
    $this->datoss = $datos->fetchall();
   }

   public function buscar_partes($id){

   $sql="SELECT * FROM partes where id_servicio_especial='".$id."'";
  
   $datos = $this->_db->query($sql);
    $datos->setFetchMode(PDO::FETCH_ASSOC);
    $this->datoss = $datos->fetchall();
   }

   public function buscar_tecnico(){

   $sql="SELECT * FROM tecnico where id_usuario='".session::get('id_usuario')."'";
  
   $datos = $this->_db->query($sql);
    $datos->setFetchMode(PDO::FETCH_ASSOC);
    $this->datoss = $datos->fetch();
   }

   public function buscar_fotos($id){

  $sql="SELECT * FROM foto_servicio_especial where id_servicio_especial='".$id."'";
  
   $datos = $this->_db->query($sql);
    $datos->setFetchMode(PDO::FETCH_ASSOC);
    
  
$this->datoss = $datos->fetchall();
if(count($this->datoss) == 0){

  $this->datoss=0;
}else{

  $this->datoss;
}


   }

   public function servicio_especial($id){

   $sql="SELECT * FROM servicio_especial where id_servicio_especial='".$id."'";
  
   $datos = $this->_db->query($sql);
    $datos->setFetchMode(PDO::FETCH_ASSOC);
    $this->datoss = $datos->fetch();
   }

public function buscar_diagnostico($id){

   $sql="SELECT * FROM diagnostico where id_servicio_especial='".$id."'";
  
   $datos = $this->_db->query($sql);
    $datos->setFetchMode(PDO::FETCH_ASSOC);
    $this->datoss = $datos->fetch();
   }






public function registrar_servicio($datos,$fotos){

$software=0;
$hardware=0;
$funcionamiento=0;
$otros=0;

if(isset($datos['software'])){
$software=1;
}

if(isset($datos['hardware'])){
$hardware=1;
}

if(isset($datos['funcionamiento'])){
$funcionamiento=1;
}

if(isset($datos['otros'])){
$otros=$datos['otrosrespuesta'];
}
    if($fotos['foto']['name'][0]==''){

        if(session::get('role')==1){

        $sql="INSERT INTO servicio values ('','".$datos['servicio']."','".$software."' ,'".$hardware."' ,'".$funcionamiento."','".$otros."' , curdate() , curtime(),'".$datos['id_usuario']."','".$datos['fecha_atencion']."' ,'".$datos['hora_atencion']."' ,'pendiente','','','')";
                  $this->_db->query($sql);
        }else{

          $sql="INSERT INTO servicio values ('','".$datos['servicio']."','".$software."' ,'".$hardware."' ,'".$funcionamiento."','".$otros."' , curdate() , curtime(),'".session::get('id_usuario')."','".$datos['fecha_atencion']."' ,'".$datos['hora_atencion']."' ,'pendiente','','','')";
            $this->_db->query($sql);
        }

    }else{


      if(session::get('role')==1){
                  $sql="insert into servicio values('','".$datos['servicio']."','".$software."' ,'".$hardware."' ,'".$funcionamiento."' ,'".$otros."' , curdate() , curtime(),'".$datos['id_usuario']."','".$datos['fecha_atencion']."' ,'".$datos['hora_atencion']."' ,'pendiente','','','')";
                 $this->_db->query($sql);
                 }else{
                  $sql="insert into servicio values('','".$datos['servicio']."','".$software."' ,'".$hardware."' ,'".$funcionamiento."' ,'".$otros."' , curdate() , curtime(),'".session::get('id_usuario')."','".$datos['fecha_atencion']."' ,'".$datos['hora_atencion']."' ,'pendiente','','','')";
                 $this->_db->query($sql);
                 }

                  $id_servicio=$this->_db->lastInsertId();

if(count($fotos['foto']['name']) < 3){

$recorrido=count($fotos['foto']['name']);

}else{
$recorrido=3;
}
 for ($i=0; $i < $recorrido; $i++)
            { 
                  $target_path = "public/img/problemas/";
                  $nombre=uniqid('problema').$fotos['foto']['name'][$i];
                  $target_path = $target_path .$nombre;
                   $sql2="update servicio SET imagen_pedido".$i."='".$nombre."' WHERE id_servicio='$id_servicio'";
                  $this->_db->query($sql2);
                  move_uploaded_file($fotos['foto']['tmp_name'][$i], $target_path);
                  $obj_img = new SimpleImage();
                  $obj_img->load($target_path);
                  //$obj_img->resize(234,135);
                  $obj_img->save($target_path);
            }
}
}





   /*   $target_path = "public/img/problemas/";
                  $randon=mt_rand(1,1000);
                  $nombre='problema-'.$randon.$fotos['foto']['name'][0];
                  $target_path = $target_path .$nombre;
                  if(session::get('role')==1){
                  $sql="insert into servicio values('','".$datos['servicio']."','".$software."' ,'".$hardware."' ,'".$funcionamiento."' ,'".$otros."' , curdate() , curtime(),'".$datos['id_usuario']."','".$datos['fecha_atencion']."' ,'".$datos['hora_atencion']."' ,'pendiente','".$nombre."')";
                 $this->_db->query($sql);
                 }else{
                  $sql="insert into servicio values('','".$datos['servicio']."','".$software."' ,'".$hardware."' ,'".$funcionamiento."' ,'".$otros."' , curdate() , curtime(),'".session::get('id_usuario')."','".$datos['fecha_atencion']."' ,'".$datos['hora_atencion']."' ,'pendiente','".$nombre."')";
                 $this->_db->query($sql);
                 }
                  move_uploaded_file($fotos['foto']['tmp_name'][0], $target_path); 
                  $obj_img = new SimpleImage();
                  $obj_img->load($target_path);
                  //$obj_img->resize(234,135);
                  $obj_img->save($target_path);
}*/

   public function buscar_servicios_usuarios(){

 	 $sql="select * from servicio where id_usuario='".Session::get('id_usuario')."'";
  
     $datos =  $this->_db->query($sql);
      return $datos->fetchall();
   }


public function buscar_usuarios(){

   $sql="select * from usuario where id_role!=1 order by login ASC";
  
     $datos =  $this->_db->query($sql);
      return $datos->fetchall();
   }

public function buscar_cliente(){

   $sql="SELECT * FROM `clientes` WHERE 1 order by cliente ASC";
  
     $datos =  $this->_db->query($sql);
      return $datos->fetchall();
   }

   

   public function buscar_empresas(){

   $sql="SELECT DISTINCT empresa FROM `usuario` WHERE 1 order by empresa ASC";
  
     $datos =  $this->_db->query($sql);
      return $datos->fetchall();
   }

   

   public function buscar_servicio_usuario($servicio,$estatus){

    if($estatus=="solucionado"){

    $sql="select servicio.*, solucion_servicio.* from servicio, solucion_servicio where servicio.estatus='solucionado' and servicio.id_servicio=solucion_servicio.id_servicio and servicio.id_servicio=$servicio";
     $datos =  $this->_db->query($sql);
    }else{

      $sql="select * from servicio where id_servicio='".$servicio."'";
      $datos =  $this->_db->query($sql);

    }
      return $datos->fetch();
   }
}

?>
