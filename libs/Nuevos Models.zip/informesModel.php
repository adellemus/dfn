<?php

class informesModel extends Model
{
    public function __construct() {
        parent::__construct();
    }


public function buscar_informes(){

   $sql="SELECT clientes.*, servicio_especial.* FROM clientes,servicio_especial where servicio_especial.id_cliente=clientes.id_clientes order by cliente ASC";
  
     $datos =  $this->_db->query($sql);
      return $datos->fetchall();
   }

   public function eliminar_informe($id_servicio_especial){
   
 $sql="DELETE FROM `servicio_especial` WHERE id_servicio_especial=$id_servicio_especial";
$datos = $this->_db->query($sql);
return 0;

}


}

?>
